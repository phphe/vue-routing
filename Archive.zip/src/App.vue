<template>
  <div id="app">
      <md-whiteframe>
        <md-toolbar md-theme="blue">
          <md-button class="md-icon-button">
            <md-icon>menu</md-icon>
          </md-button>

          <h2 class="md-title" style="flex: 1">Green Safety</h2>

          <md-button class="md-icon-button">
            <md-icon>view_module</md-icon>
          </md-button>
        </md-toolbar>
      </md-whiteframe>


   
       <router-view></router-view>
  </div>
</template>

<script>

export default {
  data () {
    return {
    }
  }
}



</script>


<style src="vue-material/dist/vue-material.css"></style>

